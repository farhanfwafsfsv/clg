
import React from 'react';
import { FoodAnalysisResult } from '../types';

interface ResultDisplayProps {
  result: FoodAnalysisResult;
  onReset: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onReset }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Fresh': return 'text-green-600 bg-green-50 border-green-200';
      case 'Caution': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'Expired': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getProgressColor = (score: number) => {
    if (score > 70) return 'bg-green-500';
    if (score > 40) return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full max-w-xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className={`p-6 rounded-2xl border-2 mb-6 ${getStatusColor(result.status)}`}>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-bold">{result.status}</h2>
          <span className="text-sm font-semibold px-3 py-1 bg-white/50 rounded-full uppercase tracking-wider">
            AI Score: {result.safetyScore}%
          </span>
        </div>
        <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden mb-4">
          <div 
            className={`h-full transition-all duration-1000 ${getProgressColor(result.safetyScore)}`}
            style={{ width: `${result.safetyScore}%` }}
          />
        </div>
        <p className="text-lg font-medium italic opacity-90">"{result.recommendation}"</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-400 uppercase mb-3">Observations</h3>
          <ul className="space-y-2">
            {result.observations.map((obs, i) => (
              <li key={i} className="flex items-start gap-2 text-gray-700 text-sm">
                <span className="text-blue-500 mt-1">•</span> {obs}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-400 uppercase mb-3">Spoilage Signs</h3>
          <ul className="space-y-2">
            {result.spoilageSigns.map((sign, i) => (
              <li key={i} className="flex items-start gap-2 text-gray-700 text-sm">
                <span className="text-red-500 mt-1">!</span> {sign}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <button
        onClick={onReset}
        className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl shadow-lg hover:bg-black transition-transform active:scale-95"
      >
        Analyze Another Item
      </button>
    </div>
  );
};

export default ResultDisplay;
