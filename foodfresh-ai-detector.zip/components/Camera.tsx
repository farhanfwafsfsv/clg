
import React, { useRef, useState, useCallback } from 'react';

interface CameraProps {
  onCapture: (image: string) => void;
  onClose: () => void;
}

const Camera: React.FC<CameraProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Could not access camera. Please check permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [stream]);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const imageData = canvasRef.current.toDataURL('image/jpeg');
        onCapture(imageData);
        stopCamera();
        onClose();
      }
    }
  };

  React.useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full max-h-[80vh] object-cover"
      />
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="flex gap-6 mt-8">
        <button
          onClick={() => { stopCamera(); onClose(); }}
          className="bg-white/20 text-white px-6 py-3 rounded-full hover:bg-white/30 transition shadow-lg"
        >
          Cancel
        </button>
        <button
          onClick={capturePhoto}
          className="bg-green-500 text-white w-20 h-20 rounded-full flex items-center justify-center hover:bg-green-600 transition shadow-xl border-4 border-white/50"
        >
          <div className="w-12 h-12 rounded-full border-2 border-white"></div>
        </button>
      </div>
    </div>
  );
};

export default Camera;
