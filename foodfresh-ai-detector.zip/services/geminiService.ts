
import { GoogleGenAI, Type } from "@google/genai";
import { FoodAnalysisResult, FoodMetadata } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeFood(
  base64Image: string,
  metadata: FoodMetadata
): Promise<FoodAnalysisResult> {
  // Remove data URL prefix if present
  const base64Data = base64Image.split(',')[1] || base64Image;

  const prompt = `
    Analyze this food image and the following context:
    - Preparation Time: ${metadata.prepTime}
    - Current Time: ${metadata.currentTime}
    - Refrigerated: ${metadata.isRefrigerated ? 'Yes' : 'No'}
    ${metadata.isRefrigerated ? `- Refrigeration Duration: ${metadata.refrigerationDuration}` : ''}

    Examine visual cues such as mold, discoloration, texture changes, wilting, or drying.
    Combine visual data with the storage metadata to determine the food safety status.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: {
            type: Type.STRING,
            description: "The safety status of the food (Fresh, Caution, Expired, Unknown)",
          },
          safetyScore: {
            type: Type.NUMBER,
            description: "A safety score from 0 to 100",
          },
          confidence: {
            type: Type.NUMBER,
            description: "AI confidence level from 0 to 1",
          },
          observations: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Visual and temporal observations",
          },
          recommendation: {
            type: Type.STRING,
            description: "Actionable advice for the user",
          },
          spoilageSigns: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Specific signs of spoilage detected or potentially present",
          },
        },
        required: ["status", "safetyScore", "confidence", "observations", "recommendation", "spoilageSigns"],
      }
    }
  });

  const resultText = response.text || "{}";
  return JSON.parse(resultText) as FoodAnalysisResult;
}
